<?php
/**
 * Plugin meta for single post or page type.
 *
 * @package    BIRS HF SCRIPTS
 * @link       http://github.com/jasenmichael/birs_hf_scripts
 */?>
 <div class="bhfs_meta_control">

	<p><?php esc_html_e('The script in the following textbox will be inserted to the &lt;head&gt; section', 'birs-hf-scriptss'); ?>.</p>
	<p>
		<textarea name="_inpost_head_script[synth_header_script]" rows="5" style="width:98%;font-family:monospace;"><?php if(!empty($meta['synth_header_script'])) echo $meta['synth_header_script']; ?></textarea>
	</p>
</div>

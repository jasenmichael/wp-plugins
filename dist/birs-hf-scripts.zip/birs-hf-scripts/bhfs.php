<?php
/**
 * Plugin Name: BIRS HF Scripts
 * Plugin URI: http://github.com/jasenmichael/birs_hf_scripts
 * Description: Insert scripts to your wp_head and/or wp_footer.
 * Version: 1.0.0
 * Domain Path: /lang
 * License: GPLv2 or later
 */


define('bhfs_PLUGIN_DIR',str_replace('\\','/',dirname(__FILE__)));

if ( !class_exists( 'HeaderAndFooterScripts' ) ) {

	class HeaderAndFooterScripts {

		function __construct() {

			add_action( 'init', array( &$this, 'init' ) );
			add_action( 'admin_init', array( &$this, 'admin_init' ) );
			add_action( 'admin_menu', array( &$this, 'admin_menu' ) );
			add_action( 'wp_head', array( &$this, 'wp_head' ), \get_option('bhfs_insert_header_priority', 10) );
			add_action( 'wp_footer', array( &$this, 'wp_footer' ), \get_option('bhfs_insert_footer_priority', 10) );

		}

		function init() {

			load_plugin_textdomain( 'birs-hf-scriptss', false, dirname( plugin_basename ( __FILE__ ) ).'/lang' );
		}

		function admin_init() {

			// register settings for sitewide script
			register_setting( 'birs-hf-scriptss', 'bhfs_insert_header', 'trim' );
			register_setting( 'birs-hf-scriptss', 'bhfs_insert_footer', 'trim' );
			register_setting( 'birs-hf-scriptss', 'bhfs_insert_header_priority', 'intval' );
			register_setting( 'birs-hf-scriptss', 'bhfs_insert_footer_priority', 'intval' );

			// add meta box to all post types
			foreach ( get_post_types( '', 'names' ) as $type ) {
				add_meta_box('bhfs_all_post_meta', esc_html__('Insert Script to &lt;head&gt;', 'birs-hf-scriptss'), 'bhfs_meta_setup', $type, 'normal', 'high');
			}

			add_action('save_post','bhfs_post_meta_save');
		}

		// adds menu item to wordpress admin dashboard
		function admin_menu() {
			$page = add_submenu_page( 'options-general.php', esc_html__('BIRS HF Scripts', 'birs-hf-scriptss'), esc_html__('BIRS HF Scripts', 'birs-hf-scriptss'), 'manage_options', __FILE__, array( &$this, 'bhfs_options_panel' ) );
			}

		function wp_head() {
			$meta = get_option( 'bhfs_insert_header', '' );
			if ( $meta != '' ) {
				echo $meta, "\n";
			}

			$bhfs_post_meta = get_post_meta( get_the_ID(), '_inpost_head_script' , TRUE );
			if ( is_singular() && $bhfs_post_meta != '' ) {
				echo $bhfs_post_meta['synth_header_script'], "\n";
			}

		}

		function wp_footer() {
			if ( !is_admin() && !is_feed() && !is_robots() && !is_trackback() ) {
				$text = get_option( 'bhfs_insert_footer', '' );
				$text = convert_smilies( $text );
				$text = do_shortcode( $text );

				if ( $text != '' ) {
					echo $text, "\n";
				}
			}
		}

		function bhfs_options_panel() {
				// Load options page
				require_once(bhfs_PLUGIN_DIR . '/inc/options.php');
		}
	}

	function bhfs_meta_setup() {
		global $post;

		// using an underscore, prevents the meta variable
		// from showing up in the custom fields section
		$meta = get_post_meta($post->ID,'_inpost_head_script',TRUE);

		// instead of writing HTML here, lets do an include
		include_once(bhfs_PLUGIN_DIR . '/inc/meta.php');

		// create a custom nonce for submit verification later
		echo '<input type="hidden" name="bhfs_post_meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
	}

	function bhfs_post_meta_save($post_id) {
		// authentication checks

		// make sure data came from our meta box
		if ( ! isset( $_POST['bhfs_post_meta_noncename'] )
			|| !wp_verify_nonce($_POST['bhfs_post_meta_noncename'],__FILE__)) return $post_id;

		// check user permissions
		if ( $_POST['post_type'] == 'page' ) {

			if (!current_user_can('edit_page', $post_id))
				return $post_id;

		} else {

			if (!current_user_can('edit_post', $post_id))
				return $post_id;

		}

		$current_data = get_post_meta($post_id, '_inpost_head_script', TRUE);

		$new_data = $_POST['_inpost_head_script'];

		bhfs_post_meta_clean($new_data);

		if ($current_data) {

			if (is_null($new_data)) delete_post_meta($post_id,'_inpost_head_script');

			else update_post_meta($post_id,'_inpost_head_script',$new_data);

		} elseif (!is_null($new_data)) {

			add_post_meta($post_id,'_inpost_head_script',$new_data,TRUE);

		}

		return $post_id;
	}

	function bhfs_post_meta_clean(&$arr) {

		if (is_array($arr)) {

			foreach ($arr as $i => $v) {

				if (is_array($arr[$i])) {
					bhfs_post_meta_clean($arr[$i]);

					if (!count($arr[$i])) {
						unset($arr[$i]);
					}

				} else {

					if (trim($arr[$i]) == '') {
						unset($arr[$i]);
					}
				}
			}

			if (!count($arr)) {
				$arr = NULL;
			}
		}
	}

	$bhfs_header_and_footer_scripts = new HeaderAndFooterScripts();
}

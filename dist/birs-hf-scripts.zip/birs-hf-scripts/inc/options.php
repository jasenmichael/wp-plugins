<?php ?>

<div class="wrap">
  <h2><?php esc_html_e( 'BIRS HF Scripts - Options', 'birs-hf-scriptss'); ?></h2>

  <hr />
  <div id="poststuff">
      <div id="post-body-content">
        <div class="postbox">
          <div class="inside">
            <form name="dofollow" action="options.php" method="post">
  
              <?php settings_fields( 'birs-hf-scriptss' ); ?>
  
              <h3 class="bhfs-labels" for="bhfs_insert_header"><?php esc_html_e( 'Header scripts:', 'birs-hf-scriptss'); ?></h3>
              <p><?php esc_html_e( 'The following script, if any, will be inserted into the &lt;head&gt; section using wp_head hook.', 'birs-hf-scriptss'); ?></p>
              <textarea style="width:98%;font-family:monospace;" rows="10" cols="57" id="insert_header" name="bhfs_insert_header"><?php echo esc_html( get_option( 'bhfs_insert_header' ) ); ?></textarea>
  
              <p><label for="bhfs_insert_header_priority"><?php esc_html_e('Priority', 'birs-hf-scriptss'); ?></label>
              <input type="number" value="<?php echo \esc_html( \get_option( 'bhfs_insert_header_priority', 10 ) ); ?>" name="bhfs_insert_header_priority" id="bhfs_insert_header_priority" style="width:6em;" /> <?php \esc_html_e('Default', 'birs-hf-scriptss'); ?>: 10</p><hr />
  
              <h3 class="bhfs-labels footerlabel" for="bhfs_insert_footer"><?php esc_html_e( 'Footer scripts:', 'birs-hf-scriptss'); ?></h3>
              <p><?php esc_html_e( 'The following script, if any, will be inserted before &lt;/body&gt; tag using wp_footer hook.', 'birs-hf-scriptss'); ?></p>
              <textarea style="width:98%;font-family:monospace;" rows="10" cols="57" id="bhfs_insert_footer" name="bhfs_insert_footer"><?php echo esc_html( get_option( 'bhfs_insert_footer' ) ); ?></textarea>
  
              <p><label for="bhfs_insert_footer_priority"><?php _e('Priority'); ?></label>
              <input type="number" value="<?php echo \esc_html( \get_option( 'bhfs_insert_footer_priority', 10 ) ); ?>" name="bhfs_insert_footer_priority" id="bhfs_insert_footer_priority" style="width:6em;" /> <?php \esc_html_e('Default', 'birs-hf-scriptss'); ?>: 10</p>
  
            <p class="submit">
              <input class="button button-primary" type="submit" name="Submit" value="<?php esc_html_e( 'Save settings', 'birs-hf-scriptss'); ?>" />
            </p>
  
            </form>
          </div>
        </div>
      </div>
  </div>
</div>
